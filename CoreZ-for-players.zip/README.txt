COREZ SERVERPACK DIAGNOSTICS

Players:
1. Wait for Steam to finish updating your mods.
2. In the DayZ launcher, find CoreZ Serverpack and open its folder.
3. Extract all files from this ZIP into the same folder.
4. Double-click Run-Diagnostics.bat. Administrator rights are not required.
5. Paste the path to the mod folder when prompted.
6. Send the CoreZ_*.csv and CoreZ_*.txt reports from your Desktop to the admin.

Select the mod copy actually loaded by the launcher.
Reports include your computer name (e.g. DESKTOP-ABC), mod path, file names,
sizes, modification dates and SHA-256 hashes of PBO/BISIGN files.
The mod path may include your Windows account name.
The script does not modify mod files or send reports automatically.

The BAT launcher uses PowerShell -ExecutionPolicy Bypass for this process
so the diagnostic script does not need a digital signature under normal
PowerShell execution policies. It does not change the system policy.
Organization-enforced Group Policy or application controls may still block it.
Windows may show a downloaded-file warning; inspect the files before running.

Administrator comparison (PowerShell in the diagnostics folder):
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Compare-CoreZ.ps1 -ServerCsv .\SERVER.csv -PlayerCsv .\PLAYER.csv

DIFFERENT_CONTENT = file contents differ
MISSING_ON_PLAYER = present on server, missing on player
EXTRA_ON_PLAYER = extra file on player

Comparison uses relative file names and SHA-256, not dates or local paths.
Matching reports do not validate server keys, other mods or launcher settings.
