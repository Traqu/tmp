@echo off
setlocal
title CoreZ Serverpack Diagnostics
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-CoreZ.ps1"
if errorlevel 1 echo Diagnostics failed. See the error above.
pause
endlocal
