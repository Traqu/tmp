param(
    [string]$ModPath,
    [string]$OutputDirectory = [Environment]::GetFolderPath('Desktop'),
    [string]$Label = $env:COMPUTERNAME
)
$ErrorActionPreference = 'Stop'
try {
    if (-not $ModPath) {
        Write-Host 'Enter the CoreZ Serverpack folder (e.g. Steam\steamapps\workshop\content\221100\3246720618).'
        Write-Host 'In the DayZ launcher: Mods -> CoreZ Serverpack -> Open folder.'
        $ModPath = (Read-Host 'Mod folder path').Trim().Trim('"')
    }
    $root = (Resolve-Path -LiteralPath $ModPath).Path
    $addons = Join-Path $root 'Addons'
    if (-not (Test-Path -LiteralPath $addons -PathType Container)) {
        throw 'The selected folder has no Addons directory. Select the main mod folder.'
    }
    $files = @(Get-ChildItem -LiteralPath $addons -Recurse -File |
        Where-Object { $_.Extension -in '.pbo', '.bisign' } | Sort-Object FullName)
    if (-not @($files | Where-Object Extension -eq '.pbo').Count) { throw 'No PBO files found.' }
    $rows = @()
    $index = 0
    foreach ($file in $files) {
        $index++
        Write-Progress -Activity 'Calculating CoreZ SHA-256 hashes' -Status $file.Name -PercentComplete (100 * $index / $files.Count)
        $beforeLength = $file.Length
        $beforeTime = $file.LastWriteTimeUtc
        $hash = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
        $file.Refresh()
        if ($file.Length -ne $beforeLength -or $file.LastWriteTimeUtc -ne $beforeTime) {
            throw "File changed while being read: $($file.Name). Wait for the update to finish and try again."
        }
        $rows += [pscustomobject]@{
            ComputerName = $env:COMPUTERNAME
            Label = $Label
            ModPath = $root
            RelativePath = $file.FullName.Substring($root.TrimEnd('\').Length + 1).Replace('\', '/')
            Bytes = $file.Length
            LastWriteTimeUtc = $file.LastWriteTimeUtc.ToString('o')
            SHA256 = $hash
        }
    }
    Write-Progress -Activity 'Calculating CoreZ SHA-256 hashes' -Completed
    if (-not $OutputDirectory) { $OutputDirectory = $PSScriptRoot }
    $null = New-Item -ItemType Directory -Path $OutputDirectory -Force
    $safeLabel = $Label -replace '[^a-zA-Z0-9_.-]', '_'
    $stem = 'CoreZ_{0}_{1}' -f $safeLabel, (Get-Date -Format 'yyyyMMdd_HHmmss')
    $csv = Join-Path $OutputDirectory ($stem + '.csv')
    $rows | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding UTF8
    $info = @(
        "ComputerName: $env:COMPUTERNAME",
        "Label: $Label",
        "ModPath: $root",
        "CollectedUtc: $([DateTime]::UtcNow.ToString('o'))",
        "PBO: $(@($files | Where-Object Extension -eq '.pbo').Count)",
        "BISIGN: $(@($files | Where-Object Extension -eq '.bisign').Count)"
    )
    $meta = Join-Path $root 'meta.cpp'
    if (Test-Path -LiteralPath $meta) { $info += ''; $info += Get-Content -LiteralPath $meta }
    $info | Set-Content -LiteralPath (Join-Path $OutputDirectory ($stem + '.txt')) -Encoding UTF8
    Write-Host "Done. Send the CSV and TXT reports to the administrator: $csv" -ForegroundColor Green
} catch {
    Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
